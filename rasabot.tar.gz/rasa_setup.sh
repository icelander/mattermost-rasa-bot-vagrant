#!/bin/bash

apt-get install python3-pip -y

pip3 install rasa mmpy_bot